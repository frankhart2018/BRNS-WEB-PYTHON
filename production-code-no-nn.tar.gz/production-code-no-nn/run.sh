export FLASK_APP=app.py
flask run
