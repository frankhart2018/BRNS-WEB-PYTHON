import os

files = ["cc", "colorized", "contrast", "gamma_corrected", "grayscale", "hsi", "im", "inv", "obj", "om", "original", "resize", "vcminus", "vcplus", "vd", "ve", "jaccard"]

print()
print("Step 1) Creating intermediary files.")

for file in files:
    if not os.path.exists("static/" + file):
        os.mkdir("static/" + file)
